<!DOCTYBE html>
<head>
<title>Building Company</title>

</head>
<style>
body{
  background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
  margin: 0;
  padding: 0;
  font-family: sans-serif;

}
menu ul li {padding: 10px; display-inline-block;}
menu ul{
  margin: 0;
  padding: 0;
  list-style:none;
  line-height: 30px;

}
header{
  background:#DDD;
  color:#676767;
  font-size: 50px;
  text-align: center;
  font-style: italic;



}
h1{
  align:center;
  font-size: 60px;
  color:#b15ec4;

  font-style: italic;


}
h2{
  align:center;
  font-size: 30px;
  color:#FFF;

  font-style: italic;


}

menu{
width:60%;
background: #ABACAB;
overflow: auto;
border-radius: 10px;
box-shadow: 0px 0px 19px
rgba(0,0,0,0.15);
}
 menu li{
  float: left;
}
 menu ul li a{
  background: #FFF;
  text-decoration: none;
  width: 100px;
  display: block;
  text-align:center;
  color: ##b15ec4;
  font-size: 18px;
  font-family: sans-serif;
  letter-spacing: 0.5px;
}
li a:hover {
  color: #b15ec4;
  opacity: ;
  font-size: 10px;

}
body{
  background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
  margin: 0;
  padding: 0;
  font-family: sans-serif;

}p{
  font-size: 20px;
  font-style: italic;
  color:#000;
text-align: center;
}


ul{
  margin: 0;
  padding: 0;
  list-style: none;
  line-height: 50px;
  text-align: center;
}
li{
  float: left;
  text-align: center;
}
ul li{
  display: inline-inline-block; padding: 20px;
}
fieldset{
  width:70%
}
 menu ul li a{
  background: #ABACAB;
  text-decoration: none;
  width: 120px;
  display: block;
  text-align:center;
  color: #142b47;
  font-size: 18px;
  font-style:italic;
  font-family: sans-serif;
  letter-spacing: 1.5px;
}
li a:hover {
  color: orange;
  opacity: ;
  font-size: 19px;

}
</style>
<body>
<center>
  <header>
  <h1>BUILD YOUR DREAM</h1>
</header>




<menu>
<div class="navigation">
<ul>
<li><a href="users.php">Users</a></li>
<li><a href="buildings.php">Buildings</a></li>
<li><a href="orders.php">Orders</a></li>
<li><a href="about.php">About Us</a></li>
<li><a href="contact.php">Contact Us</a></li>
<li><a href="help.php">Help</a></li>
</ul>
</div>
</menu>
</br>
<h2>Welcome To Our Company</h2></br>


    <p> We are a construction start up company which came with new and modern designs with high quality and low price ,,,</p>
    <p>We hope you get a look at our previous graphics models and we are sure you will like it.</p>
  </center>


</body>
</html>
