<html dit="RTL" lang="ar">

  <head>
    <meta chaset="utf-8">
    <meta name="description"contain="users of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }
  p{
    font-style: italic;
    color:inherit;
  }

  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
 <center>
   <h1>please,Enter Your Updates on Order Information</h1>
   <p>Enter The Buyer Name To Update His Order<p>
<form action="update_matirial.php" method="post">
Buyer Name :<input type="text" name="cl_name"></br></br>

<button type="submit"  style="width: 200px; height: 50px; " name="submit">Show </button>

</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name5='';
//database connection
$conn = mysqli_connect($host, $user, $pass,'bulding');

//connection failed
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br><hr>';

if ( isset( $_POST['submit'] ) ) {
  $name5 = $_REQUEST['cl_name'];

$sql="select* from company where name='$name5'";
$retval=mysqli_query($conn, $sql);

if(mysqli_num_rows($retval) > 0){
 while($row = mysqli_fetch_assoc($retval)){

    echo "<form action='update_matirial.php' method='post'>".
    "Buyer Name :<input type='text' name='cl_name1' value={$row['name']}>".
    "<input type='hidden' name='cl_name2' value={$row['name']}></br></br>".

            "Buyer Phone :<input type='text' name='phonee1' value={$row['phone']}></br></br>".
            "Buyer E_mail :<input type='text' name='mail1'  value={$row['e_maile']}></br></br>".

            "Buyer Address  :<input type='text' name='loc1'  value={$row['location']} ></br></br>".
          "  Material :<input type='text' name='materiall1'  value={$row['material']}></br></br>".
          "  Quantity :<input type='text' name='quant1'  value={$row['quantity']}></br></br>".
            "Price :<input type='text' name='price1'  value={$row['price']}></br></br>".

"<button type='submit'  style='width: 200px; height: 50px;  ' name='submit2'>Update</button></br></br><hr>";
}
}
}

}
if ( isset( $_POST['submit2'] ) ) {
  $name =$_REQUEST['cl_name1'];
  $name5=$_REQUEST['cl_name2'];
  $phone = $_REQUEST['phonee1'];
  $e_maile = $_REQUEST['mail1'];

  $location = $_REQUEST['loc1'];
  $material = $_REQUEST['materiall1'];
  $quantity = $_REQUEST['quant1'];
  $price = $_REQUEST['price1'];

$sql2="update company set name='$name',phone='$phone',e_maile='$e_maile',location='$location',material='$material', quantity='$quantity',price='$price'  where name='$name5'";
if(mysqli_query($conn, $sql2)){
echo "Well Done Your Updates are Recorded";
}
else{
echo "Could not update record: ". mysqli_error($conn);
}

}
mysqli_close($conn);
?>
<form action="orders.php" method="post">
<button type="submit"  style="width: 200px; height: 60px; " name="home">Back TO Home OF Orders </button>

</form>
</center>

</body>
</html>
