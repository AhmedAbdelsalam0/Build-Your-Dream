<html dit="RTL" lang="ar">

  <head>
    <meta chaset="utf-8">
    <meta name="description"contain="users of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }
  p{
    font-style: italic;
    color:inherit;
  }

  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
 <center>
   <h1>please,Enter User Name To Delete</h1>
   <p>Enter The User Name To Delete His Information<p>
<form action="delete_user.php" method="post">
user name :<input type="text" name="username"></br></br>

<button type="submit"  style="width: 200px; height: 50px; " name="submit">delete </button>

</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name2='';
//database connection
$conn = mysqli_connect($host, $user, $pass,'bulding');

//connection failed
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br>';
if ( isset( $_POST['submit'] ) ) {
  $name2 = $_REQUEST['username'];

$sql="select* from user where name='$name2'";
$retval=mysqli_query($conn, $sql);
if(mysqli_num_rows($retval) > 0){
 while($row = mysqli_fetch_assoc($retval)){

	 echo "<form action='delete_user.php' method='post'>".
 	"user name :<input type='text' name='username' value={$row['name']}></br></br>".
 	"<input type='hidden' name='username1' value={$row['name']}></br></br>".
 				"user phone :<input type='text' name='userphone' value={$row['phone']}></br></br>".
 				"user capital :<input type='text' name='usercapital' value={$row['capital']}></br></br>".
 				"user order :<input type='text' name='userorder' value={$row['request']}></br></br>".
 				"user password :<input type='password' name='userpass' value={$row['password']}></br></br>".
 				"user e_mail :<input type='text' name='user_email' value={$row['e_mali']}></br></br>".

 "<button type='submit'  style='width: 200px; height: 50px; ' name='submit2'>delete</button></br></br><hr>";
}
}
}

}
if ( isset( $_POST['submit2'] ) ) {
$name = $_REQUEST['username1'];
$name2=$_REQUEST['username1'];
/*$phone = $_REQUEST['userphone1'];
$capital = $_REQUEST['usercapital1'];
$request = $_REQUEST['userorder1'];
$password = $_REQUEST['userpass1'];
$e_mali = $_REQUEST['user_email1'];*/


//$sql2="update employee set name='$name',phone='$phone',address='$address',ssn='$ssn',salary='$salary' where name='$name2'";
$sql2 = "DELETE FROM user WHERE  name='$name2'" ;
if(mysqli_query($conn, $sql2)){
echo "delete done";
}
else{
echo "Could not delete record: ". mysqli_error($conn);
}

}
mysqli_close($conn);
?>
<form action="users.php" method="post">
<button type="submit"  style="width: 200px; height: 60px; " name="home">Back TO Home OF Users </button>




</body>
</html>
