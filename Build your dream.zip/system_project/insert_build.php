<html dit="RTL" lang="ar">

  <head>
    <meta chaset="utf-8">
    <meta name="description"contain="users of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }

  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
 <center>
   <h1>Please Enter Building Specifications</h1>
<form action="insert_build.php" method="post">
  User_Name            :<input type="text" name="us_name"></br></br>
Area                   :<input type="text" name="area_build"></br></br>
Drawing                :<input type="text" name="draw"></br></br>
Location               :<input type="text" name="loc"></br></br>
Number Of Interfaces   :<input type="text" name="n_interfaces"></br></br>
License                :<input type="text" name="licen"></br></br>
Number Of Floor        : <input type="text" name="Num_floor"></br></br>
Neighbors_Instructions :<input type="text" name="inst"></br></br>

<button type="submit"  style="width: 200px; height: 50px; " name="submit">insert </button>

</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
//database connection
$conn = mysqli_connect($host, $user, $pass,'bulding');

//connection faile
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br>';
if ( isset( $_POST['submit'] ) ) {
  $user_name =$_REQUEST['us_name'];
  $area = $_REQUEST['area_build'];
$the_drawing = $_REQUEST['draw'];
$location = $_REQUEST['loc'];
$N_interface = $_REQUEST['n_interfaces'];
$license = $_REQUEST['licen'];
$N_floor = $_REQUEST['Num_floor'];
$ni_instru = $_REQUEST['inst'];

$sql="insert into building values('$area','$the_drawing','$location','$N_interface','$license','$N_floor','$ni_instru','$user_name')";
//$sql3="insert into userr values('$phone')";
if(mysqli_query($conn, $sql)){

  echo "Thanks,Your Build Will Be Ready Soon";
}


else{
echo "Could not insert record: ". mysqli_error($conn);
}
}
}
//insert in section table

mysqli_close($conn);
?>


<form action="buildings.php" method="post">
<button type="submit"  style="width: 200px; height: 60px; " name="home">Back TO Home OF Buildings </button>
</form>
</center>
</body>
</html>
