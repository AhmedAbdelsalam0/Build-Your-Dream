<html dit="RTL" lang="ar">

  <head>
    <meta chaset="utf-8">
    <meta name="description"contain="users of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }

  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
 <center>
   <h1>Please Enter User Data</h1>
<form action="insert_pro_system.php" method="post">
user id :<input type="text" name="userid"></br></br>
user name :<input type="text" name="username"></br></br>
user e_mail :<input type="email" name="user_email"></br></br>
user pass :<input type="password" name="userpass"></br></br>
user order :<input type="text" name="userorder"></br></br>
user capital :<input type="text" name="usercapital"></br></br>
user phone :<input type="text" name="userphone"></br></br>

<button type="submit"  style="width: 200px; height: 60px; " name="submit">insert </button>

</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
//database connection
$conn = mysqli_connect($host, $user, $pass,'bulding');

//connection faile
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br> </br>';
if ( isset( $_POST['submit'] ) ) {
  $uid = $_REQUEST['userid'];
$name = $_REQUEST['username'];
$e_mail = $_REQUEST['user_email'];
$pass = $_REQUEST['userpass'];
$request = $_REQUEST['userorder'];
$capital = $_REQUEST['usercapital'];
$phone = $_REQUEST['userphone'];
$sql="insert into user values('$uid','$name','$e_mail','$pass','$request','$capital','$phone')";
//$sql3="insert into userr values('$phone')";
if(mysqli_query($conn, $sql)){
  echo "insert done </br> </br>";

}


else{
echo "Could not insert record: ". mysqli_error($conn);
}
}

}

//insert in section table

mysqli_close($conn);

?>

<table >
  <tr>
  <form action="users.php" method="post">
  <button type="submit"  style="width: 200px; height: 60px; " name="home">Back TO Home OF Users </button>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</form>
 <form action="insert_build.php" method="post" >
  <button type="submit"  style="width: 200px; height: 60px; " name="home">Go To Insert Building </button>
  </form>
</form>
</tr>
</table>
</center>






</body>
</html>
