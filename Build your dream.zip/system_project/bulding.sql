-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2020 at 07:31 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bulding`
--

-- --------------------------------------------------------

--
-- Table structure for table `building`
--

CREATE TABLE `building` (
  `area` varchar(80) NOT NULL,
  `the_drawing` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `N_interface` int(11) DEFAULT NULL,
  `license` varchar(100) DEFAULT NULL,
  `N_floor` int(11) DEFAULT NULL,
  `ni_instru` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `building`
--

INSERT INTO `building` (`area`, `the_drawing`, `location`, `N_interface`, `license`, `N_floor`, `ni_instru`, `user_name`) VALUES
('', '', '', 0, '', 0, '', NULL),
('200', 'good', 'alex', 4, '1025', 3, 'polite', 'shrouk'),
('300', 'very good', 'sharm', 5, '3625', 4, 'polite', 'samira');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `material` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `e_maile` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`material`, `quantity`, `price`, `name`, `phone`, `e_maile`, `location`) VALUES
('sand', 100, 600, 'shrouk', '1236547', 'sh@gamail.com', 'gharbya');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `e_mali` varchar(100) DEFAULT NULL,
  `password` int(11) DEFAULT NULL,
  `request` varchar(100) DEFAULT NULL,
  `capital` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `name`, `e_mali`, `password`, `request`, `capital`, `phone`) VALUES
(1, 'shrouk', 'SHROUK', 25639, 'house', 'cairo', '7575757'),
(2, 'samira', 'SAMIRA', 369147, 'flat', 'cairo', '987564'),
(3, 'ahmed', 'AHMED', 52, 'company', 'cairo', '15962'),
(4, 'ahmed1', 'AHMED1', 56739, 'park', 'cairo', '04158236'),
(5, 'radwa', 'RADWA@gmail.com', 256347, 'flat', 'cairo', '04158236');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `building`
--
ALTER TABLE `building`
  ADD PRIMARY KEY (`area`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
