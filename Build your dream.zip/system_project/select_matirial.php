<html dit="RTL" lang="ar">

  <head>
    <meta chaset="utf-8">
    <meta name="description"contain="buildings of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }

  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
 <center>
   <h1>Registered Orderd</h1>
<form action="select_matirial.php" method="post">

<button type="submit"  style="width: 220px; height: 60px; " name="submit">Show a Specific Order </button>
</form>
<br><br>
<form action="select_matirial.php" method="post">
<button type="submit"  style="width: 200px; height: 60px; " name="submit3">Show All Orders Recorded </button>
</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name='';


//database connection
$conn = mysqli_connect($host, $user, $pass,'bulding');
//connection failed
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br> <hr>';
if ( isset( $_POST['submit'] ) ) {
  echo "<form action='select_matirial.php' method='post'>".
  "Buyer_Name  :<input type='text' name='buy_name'></br></br>".


"<button type='submit'  style='width: 200px; height: 50px; ' name='submit2'>show</button></br></br><hr>";
}
if ( isset( $_POST['submit2'] ) ) {
  $buyer_name = $_REQUEST['buy_name'];

$sql="select* from company where name='$buyer_name' " ;
$retval=mysqli_query($conn, $sql);
if(mysqli_num_rows($retval) > 0){
  echo "<table border=1 ><tr><th>Buyer_Name</th><th>Buyer_phone</th><th>Buyer_E_mail</th><th>Buyer_Address</th><th>Material</th><th>Quantity</th><th>Price</th></tr>";

 while($row = mysqli_fetch_assoc($retval)){
 echo "<tr><td>".$row["name"]."</td><td>".$row["phone"]."</td><td>".$row["e_maile"]."</td><td>".$row["location"]."</td><td>".$row["material"]."</td><td>".$row["quantity"]."</td><td>".$row["price"]."</td></tr>";}
  //end of while
 echo "</table>";
}
else{
echo "0 results";
} }

if ( isset( $_POST['submit3'] ) ) {

$sql2="select* from company ";
$retval2=mysqli_query($conn, $sql2);
if(mysqli_num_rows($retval2) > 0){
echo "<table border=1 ><tr><th>Buyer_Name</th><th>Buyer_phone</th><th>Buyer_E_mail</th><th>Buyer_Address</th><th>Material</th><th>Quantity</th><th>Price</th></tr>";
while($row = mysqli_fetch_assoc($retval2)){
echo "<tr><td>".$row["name"]."</td><td>".$row["phone"]."</td><td>".$row["e_maile"]."</td><td>".$row["location"]."</td><td>".$row["material"]."</td><td>".$row["quantity"]."</td><td>".$row["price"]."</td></tr>";
} //end of while
echo "</table>";
}else{
echo "0 results";
} }





}
mysqli_close($conn);
?>
<form action="orders.php" method="post">
<button type="submit"  style="width: 200px; height: 60px; " name="home">Back TO Home OF Orders </button>

</form>
</center>


</body>
</html>
