<html dit="RTL" lang="ar">

  <head>
    <meta chaset="utf-8">
    <meta name="description"contain="users of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }
  p{
    font-style: italic;
    color:inherit;
  }

  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
 <center>
   <h1>Deleting Order After Selling It</h1>
   <p>Enter The Buyer Name To Delete His Done Order<p>
<form action="delete_material.php" method="post">
Buyer Name :<input type="text" name="cl_name"></br></br>

<button type="submit"  style="width: 200px; height: 50px; " name="submit">Show First </button>

</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name2='';
//database connection
$conn = mysqli_connect($host, $user, $pass,'bulding');

//connection failed
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br>';
if ( isset( $_POST['submit'] ) ) {
  $name2 = $_REQUEST['cl_name'];

$sql="select* from company where name='$name2'";
$retval=mysqli_query($conn, $sql);
if(mysqli_num_rows($retval) > 0){
 while($row = mysqli_fetch_assoc($retval)){

   echo "<form action='delete_material.php' method='post'>".
   "Buyer Name :<input type='text' name='cl_name' value={$row['name']}>".
   "<input type='hidden' name='cl_name2' value={$row['name']}></br></br>".

           "Buyer Phone :<input type='text' name='phonee' value={$row['phone']}></br></br>".
           "Buyer E_mail :<input type='text' name='mail'  value={$row['e_maile']}></br></br>".

           "Buyer Address  :<input type='text' name='loc'  value={$row['location']} ></br></br>".
         "  Material :<input type='text' name='materiall'  value={$row['material']}></br></br>".
         "  Quantity :<input type='text' name='quant'  value={$row['quantity']}></br></br>".
           "Price :<input type='text' name='price'  value={$row['price']}></br></br>".

 "<button type='submit'  style='width: 200px; height: 50px; ' name='submit2'>Delete</button></br></br><hr>";
}
}
}

}
if ( isset( $_POST['submit2'] ) ) {
$name= $_REQUEST['cl_name2'];
$name2=$_REQUEST['cl_name2'];
/*$phone = $_REQUEST['userphone1'];
$capital = $_REQUEST['usercapital1'];
$request = $_REQUEST['userorder1'];
$password = $_REQUEST['userpass1'];
$e_mali = $_REQUEST['user_email1'];*/


//$sql2="update employee set name='$name',phone='$phone',address='$address',ssn='$ssn',salary='$salary' where name='$name2'";
$sql2 = "DELETE FROM company WHERE  name='$name2'" ;
if(mysqli_query($conn, $sql2)){
echo "Orderd is Deleted ";
}
else{
echo "Could not delete record: ". mysqli_error($conn);
}

}

mysqli_close($conn);
?>
<form action="orders.php" method="post">
<button type="submit"  style="width: 200px; height: 60px; " name="home">Back TO Home OF Orders </button>

</form>
</center>

</body>
</html>
