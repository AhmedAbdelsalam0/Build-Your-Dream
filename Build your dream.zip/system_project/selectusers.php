<html dit="RTL" lang="ar">

<body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
background-attachment: fixed;background-size:cover;
 ">
    <meta chaset="utf-8">
    <meta name="description"contain="users of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }

  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
 <center>
   <h1>Our Users</h1>
<form action="selectusers.php" method="post">

<button type="submit"  style="width: 200px; height: 50px; " name="submit">show a specific user </button>
</form>
<br><br>
<form action="selectusers.php" method="post">
<button type="submit"  style="width: 200px; height: 50px; " name="submit3">show all users </button>
</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$uid='';
$e_mali='';

//database connection
$conn = mysqli_connect($host, $user, $pass,'bulding');
//connection failed
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br>';
if ( isset( $_POST['submit'] ) ) {
  echo "<form action='selectusers.php' method='post'>".
  "ssn  :<input type='text' name='userid'></br></br>".
  "e_mail  :<input type='e_mail' name='em'></br></br>".

"<button type='submit'  style='width: 200px; height: 50px; ' name='submit2'>show</button></br></br><hr>";
}
if ( isset( $_POST['submit2'] ) ) {
  $uid = $_REQUEST['userid'];
  $e_mali=$_REQUEST['em'];
$sql="select* from user where uid='$uid' or e_mali='$e_mali'" ;
$retval=mysqli_query($conn, $sql);
if(mysqli_num_rows($retval) > 0){
echo "<table border=1 ><tr><th>uid</th><th>name</th><th>e_mali</th><th>password</th><th>request</th><th>capital></th><th>phone</th></tr>";
 while($row = mysqli_fetch_assoc($retval)){
 echo "<tr><td>".$row["uid"]."</td><td>".$row["name"]."</td><td>".$row["e_mali"]."</td><td>".$row["password"]."</td><td>".$row["request"]."</td><td>".$row["capital"]."</td><td>".$row["phone"]."</td></tr>";}
  //end of while
 echo "</table>";
}
else{
echo "0 results";
} }

if ( isset( $_POST['submit3'] ) ) {

$sql2="select* from user ";
$retval2=mysqli_query($conn, $sql2);
if(mysqli_num_rows($retval2) > 0){
echo "<table border=1 ><tr><th>uid</th><th>name</th><th>e_mail</th><th>password</th><th>request</th><th>capital</th><th>phone</th></tr>";
while($row = mysqli_fetch_assoc($retval2)){
echo "<tr><td>".$row["uid"]."</td><td>".$row["name"]."</td><td>".$row["e_mali"]."</td><td>".$row["password"]."</td><td>".$row["request"]."</td><td>".$row["capital"]."</td><td>".$row["phone"]."</td></tr>";

} //end of while
echo "</table>";
}else{
echo "0 results";
} }





}
mysqli_close($conn);
?>
<form action="users.php" method="post">
<button type="submit"  style="width: 200px; height: 60px; " name="home">Back TO Home OF Users </button>

</form>



</body>
</html>
