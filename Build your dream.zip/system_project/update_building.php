<html dit="RTL" lang="ar">

  <head>
    <meta chaset="utf-8">
    <meta name="description"contain="users of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }
  p{
    font-style: italic;
    color:inherit;
  }

  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
 <center>
   <h1>please,Enter Your Updates on Building</h1>
   <p>Enter The User Name To Update His Building<p>
<form action="update_building.php" method="post">
User name :<input type="text" name="us_name"></br></br>

<button type="submit"  style="width: 200px; height: 50px; " name="submit">show </button>

</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name='';
//database connection
$conn = mysqli_connect($host, $user, $pass,'bulding');

//connection failed
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br><hr>';

if ( isset( $_POST['submit'] ) ) {
  $name5 = $_REQUEST['us_name'];

$sql="select* from building where user_name='$name5'";
$retval=mysqli_query($conn, $sql);

if(mysqli_num_rows($retval) > 0){
 while($row = mysqli_fetch_assoc($retval)){

    echo "<form action='update_building.php' method='post'>".
    "User_Name :<input type='text' name='us_name1' value={$row['user_name']}>".
    "<input type='hidden' name='us_name2' value={$row['user_name']}></br></br>".

            "Area :<input type='text' name='area_build1' value={$row['area']}></br></br>".
            "Drawing :<input type='text' name='draw1'  value={$row['the_drawing']}></br></br>".
            "Location :<input type='text' name='loc1'  value={$row['location']}></br></br>".
            "Number Of Interfaces  :<input type='text' name='n_interfaces1'  value={$row['N_interface']} ></br></br>".
          "  License :<input type='text' name='licen1'  value={$row['license']}></br></br>".
          "  Number Of Floor :<input type='text' name='Num_floor1'  value={$row['N_floor']}></br></br>".
            "Neighbors_Instructions :<input type='text' name='inst1'  value={$row['ni_instru']}></br></br>".

"<button type='submit'  style='width: 200px; height: 50px; ' name='submit2'>update</button></br></br><hr>";
}
}
}

}
if ( isset( $_POST['submit2'] ) ) {
  $user_name =$_REQUEST['us_name1'];
  $name5=$_REQUEST['us_name2'];
  $area = $_REQUEST['area_build1'];
  $the_drawing = $_REQUEST['draw1'];
  $location = $_REQUEST['loc1'];
  $N_interface = $_REQUEST['n_interfaces1'];
  $license = $_REQUEST['licen1'];
  $N_floor = $_REQUEST['Num_floor1'];
  $ni_instru = $_REQUEST['inst1'];
  $user_name =$_REQUEST['us_name1'];
$sql2="update building set area='$area',the_drawing='$the_drawing',location='$location',N_interface='$N_interface',License='$license', N_floor='$N_floor',ni_instru='$ni_instru',user_name='$user_name'  where user_name='$name5'";
if(mysqli_query($conn, $sql2)){
echo "Well Done Your Updates are Recorded";
}
else{
echo "Could not update record: ". mysqli_error($conn);
}

}
mysqli_close($conn);
?>
<form action="buildings.php" method="post">
<button type="submit"  style="width: 200px; height: 60px; " name="home">Back TO Home OF Buildings </button>
</form>
</center>

</body>
</html>
