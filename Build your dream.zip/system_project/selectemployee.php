<html dit="RTL" lang="ar">
<body>
<form action="selectemployee.php" method="post">
<button type="submit"  style="width: 200px; height: 50px; " name="submit">عرض عميل محدد </button>
</form>
<br><br>
<form action="selectemployee.php" method="post">
<button type="submit"  style="width: 200px; height: 50px; " name="submit2">عرض جميع العملاء </button>
</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name1='';
//database connection
$conn = mysqli_connect($host, $user, $pass,'project');
//connection failed
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br>';
if ( isset( $_POST['submit'] ) ) {
  echo "<form action='selectemployee.php' method='post'>".
  "Employee name :<input type='text' name='username1' ></br></br>".
        "Employee phone :<input type='text' name='userphone1' ></br></br>".
        "Employee address :<input type='text' name='useraddress1' ></br></br>".
"<button type='submit'  style='width: 200px; height: 50px; ' name='submit3'>عرض</button>";
}
if ( isset( $_POST['submit3'] ) ) {
$name = $_REQUEST['username1'];
$phone = $_REQUEST['userphone1'];
$address = $_REQUEST['useraddress1'];
$sql="select* from employee where name='$name' or phone='$phone' or address='$address'";
$retval=mysqli_query($conn, $sql);
if(mysqli_num_rows($retval) > 0){
echo "<table border=1 ><tr><th>ID</th><th>Name</th><th>phone</th><th>address</th></tr>";
 while($row = mysqli_fetch_assoc($retval)){
 echo "<tr><td>".$row["id"]."</td><td>".$row["name"]."</td><td>".$row["phone"]."</td><td>".$row["address"]."</td></tr>";

 } //end of while
 echo "</table>";
}else{
echo "0 results";
} }

if ( isset( $_POST['submit2'] ) ) {

$sql2="select* from employee ";
$retval2=mysqli_query($conn, $sql2);
if(mysqli_num_rows($retval2) > 0){
echo "<table border=1 ><tr><th>ID</th><th>Name</th><th>phone</th><th>address</th></tr>";
 while($row = mysqli_fetch_assoc($retval2)){
 echo "<tr><td>".$row["id"]."</td><td>".$row["name"]."</td><td>".$row["phone"]."</td><td>".$row["address"]."</td></tr>";

 } //end of while
 echo "</table>";
}else{
echo "0 results";
} }





}
mysqli_close($conn);
?>



</body>
</html>
