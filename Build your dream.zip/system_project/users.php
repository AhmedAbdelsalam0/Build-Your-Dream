<html dit="RTL" lang="ar">

  <head>
    <meta chaset="utf-8">
    <meta name="description"contain="users of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }
  header{
    background:#DDD;
    color:#676767;
    font-size: 50px;
    text-align: center;
    font-style: italic;



  }


  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
<header>Welcome Our Clients</header>


<center>


<h1>Accessing In Users </h1>

                    <form action="insert_pro_system.php" method="post">
                     <button type="submit"  style="width: 200px; height: 50px; " name="button">insert user</button>
                       </form>

                       <form action="update_user.php" method="post">
                        <button type="submit"  style="width: 200px; height: 50px; " name="button2">update user</button>
                          </form>

                          <form action="selectusers.php" method="post">
                           <button type="submit"  style="width: 200px; height: 50px;  " name="button">show use or users </button>
                             </form>

                             <form action="delete_user.php" method="post">
                              <button type="submit"  style="width: 200px; height: 50px; " name="button">delete user </button>
                                </form>

<hr><hr>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <form action="building_company.php" method="post">

                                 <button type="submit"  style="width: 200px; height: 50px; " name="button">Back to Home </button>
                                   </form>
</center>



</body>
</html>
