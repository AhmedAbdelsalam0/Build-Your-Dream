<html dit="RTL" lang="ar">

  <head>
    <meta chaset="utf-8">
    <meta name="description"contain="buildings of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }

  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
 <center>
   <h1>Registered Building</h1>
<form action="select_build.php" method="post">

<button type="submit"  style="width: 220px; height: 60px; " name="submit">show a specific building </button>
</form>
<br><br>
<form action="select_build.php" method="post">
<button type="submit"  style="width: 200px; height: 50px; " name="submit3">show all buildings </button>
</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name='';


//database connection
$conn = mysqli_connect($host, $user, $pass,'bulding');
//connection failed
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br>';
if ( isset( $_POST['submit'] ) ) {
  echo "<form action='select_build.php' method='post'>".
  "user_name  :<input type='text' name='us_name'></br></br>".


"<button type='submit'  style='width: 200px; height: 50px; ' name='submit2'>show</button></br></br><hr>";
}
if ( isset( $_POST['submit2'] ) ) {
  $user_name = $_REQUEST['us_name'];

$sql="select* from building where name='$user_name' " ;
$retval=mysqli_query($conn, $sql);
if(mysqli_num_rows($retval) > 0){
  echo "<table border=1 ><tr><th>Area</th><th>the_drawing</th><th>location</th><th>num_interfaces</th><th>license</th><th>N_floor</th><th>Neighbors_Instructions</th></tr>";

 while($row = mysqli_fetch_assoc($retval)){
 echo "<tr><td>".$row["user_name"]."</td><td>".$row["area"]."</td><td>".$row["the_drawing"]."</td><td>".$row["location"]."</td><td>".$row["N_interface"]."</td><td>".$row["license"]."</td><td>".$row["N_floor"]."</td><td>".$row["ni_instru"]."</td></tr>";}
  //end of while
 echo "</table>";
}
else{
echo "0 results";
} }

if ( isset( $_POST['submit3'] ) ) {

$sql2="select* from building ";
$retval2=mysqli_query($conn, $sql2);
if(mysqli_num_rows($retval2) > 0){
echo "<table border=1 ><tr><th>User_Name</th><th>Area</th><th>the_drawing</th><th>location</th><th>num_interfaces</th><th>license</th><th>N_floor</th><th>Neighbors_Instructions</th></tr>";
while($row = mysqli_fetch_assoc($retval2)){
echo "<tr><td>".$row["user_name"]."</td><td>".$row["area"]."</td><td>".$row["the_drawing"]."</td><td>".$row["location"]."</td><td>".$row["N_interface"]."</td><td>".$row["license"]."</td><td>".$row["N_floor"]."</td><td>".$row["ni_instru"]."</td></tr>";
} //end of while
echo "</table>";
}else{
echo "0 results";
} }





}
mysqli_close($conn);
?>

<form action="buildings.php" method="post">
<button type="submit"  style="width: 200px; height: 60px; " name="home">Back TO Home OF Buildings </button>
</form>
</center>
</body>
</html>
