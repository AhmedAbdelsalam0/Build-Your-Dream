<html>
<head>
  <meta chaset="utf-8">
  <meta name="description"contain="users of bulding company">
  <title>bulding company</title>
</head>
<style>
h1{
  align:center;
  font-size: 60px;
  color:#b15ec4;

  font-style: italic;


}
button{
  background-color:#EEE;
  border: 2px solid #FF00FF;
  color:#000000;
  padding:1em 1.5em;
  text-align: center;
  text-decoration:none;
  font-size: 1em;
  display:inline;
  font-style:normal;
  width:50;
  border-radius:5px;
  box-shadow: 4px 4px 9px 0 #ADD8E6 ;
  font:bold;

}
header{
  background:#DDD;
  color:#676767;
  font-size: 50px;
  text-align: center;
  font-style: italic;



}
p{
  font-size: 20px;
  color:#000;
  font-style:italic;
  text-align: center;

}
h2{
  align:center;
  font-size: 30px;
  color:#676767;

  font-style: italic;


}

</style>
<body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
background-attachment: fixed;background-size:cover;
 ">
  <center>
    <header>Information About Our Company</header>
    <h1> Welcome With YOU </h1>


    <p>Hello everyone, we hope that our company gets your admiration. This company was specially designed to achieve people's dreams in a good building and at the lowest cost. Designed in 2019, employees work on developing it for the better and we are in a permanent development. Our company also allows the sale of raw materials at reasonable prices, and there is an appropriate privacy to maintain data  The customer and also our company are distinguished by the attractive designs and the lowest cost. We hope that we will be at your expectation and that you will like it.</p>
  </center>
    <center>
      <h2> THANKS FOR CONTRATING WITH US </h2>
    </form>

    <hr><hr>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <form action="building_company.php" method="post">

                                     <button type="submit"  style="width: 200px; height: 50px; " name="button">Back to Home </button>
                                       </form>
    </center>
  </body>
  </html>
