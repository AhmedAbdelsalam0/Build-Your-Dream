<html dit="RTL" lang="ar">

  <head>
    <meta chaset="utf-8">
    <meta name="description"contain="users of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }

  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
 <center>
   <h1>please,Enter Your Updates on Users</h1>
<form action="update_user.php" method="post">
user name :<input type="text" name="username"></br></br>

<button type="submit"  style="width: 200px; height: 50px; " name="submit">show </button>

</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name1='';
//database connection
$conn = mysqli_connect($host, $user, $pass,'bulding');

//connection failed
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br>';
if ( isset( $_POST['submit'] ) ) {
  $name1 = $_REQUEST['username'];

$sql="select* from user where name='$name1'";
$retval=mysqli_query($conn, $sql);
if(mysqli_num_rows($retval) > 0){
 while($row = mysqli_fetch_assoc($retval)){

    echo "<form action='update_user.php' method='post'>".
    "user name :<input type='text' name='username1' value={$row['name']}></br></br>".
    "<input type='hidden' name='username2' value={$row['name']}></br></br>".
          "user phone :<input type='text' name='userphone1' value={$row['phone']}></br></br>".
          "user capital :<input type='text' name='usercapital1' value={$row['capital']}></br></br>".
          "user order :<input type='text' name='userorder1' value={$row['request']}></br></br>".
          "user password :<input type='password' name='userpass1' value={$row['password']}></br></br>".
          "user e_mail :<input type='text' name='user_email1' value={$row['e_mali']}></br></br>".

"<button type='submit'  style='width: 200px; height: 50px; ' name='submit2'>update</button></br></br><hr>";
}
}
}

}
if ( isset( $_POST['submit2'] ) ) {
$name = $_REQUEST['username1'];
$name2=$_REQUEST['username2'];
$phone = $_REQUEST['userphone1'];
$capital = $_REQUEST['usercapital1'];
$request = $_REQUEST['userorder1'];
$password = $_REQUEST['userpass1'];
$e_mali = $_REQUEST['user_email1'];
$sql2="update user set name='$name',phone='$phone',capital='$capital',request='$request',password='$password', e_mali='$e_mali' where name='$name2'";
if(mysqli_query($conn, $sql2)){
echo "update done";
}
else{
echo "Could not update record: ". mysqli_error($conn);
}

}
mysqli_close($conn);
?>
<form action="users.php" method="post">
<button type="submit"  style="width: 200px; height: 60px; " name="home">Back TO Home OF Users </button>


</center>

</body>
</html>
