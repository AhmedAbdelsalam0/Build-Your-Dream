<html dit="RTL" lang="ar">

  <head>
    <meta chaset="utf-8">
    <meta name="description"contain="users of bulding company">
    <title>bulding company</title>
  </head>
  <style>
  h1{
    align:center;
    font-size: 60px;
    color:#b15ec4;
    font-weight: bold;
    font-style: italic;


  }
  button{
    background-color:#EEE;
    border: 2px solid #FF00FF;
    color:#000000;
    padding:1em 1.5em;
    text-align: center;
    text-decoration:none;
    font-size: 1em;
    display:inline;
    font-style:normal;
    width:50;
    border-radius:5px;
    box-shadow: 4px 4px 9px 0 #ADD8E6 ;
    font:bold;

  }

  </style>
  <body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
  background-attachment: fixed;background-size:cover;
   ">
 <center>
   <h1>Data Of Sell Materials </h1>
<form action="insert_matirial.php" method="post">
  Buyer Name :  <input type="text" name="cl_name"></br></br>
Buyer Phone :  <input type="text" name="phonee"></br></br>
Buyer E_mail : <input type="email" name="mail"></br></br>
Buyer Address :<input type="text" name="loc"></br></br>
Material :     <input type="text" name="materiall"></br></br>
quantity :     <input type="text" name="quant"></br></br>
Price :        <input type="text" name="pricee"></br></br>


<button type="submit"  style="width: 200px; height: 50px; " name="submit">insert </button>

</form>
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
//database connection
$conn = mysqli_connect($host, $user, $pass,'bulding');

//connection faile
if(! $conn )
{
  die('Could not connect: ' . mysqli_error());
}
else{
echo 'Connected successfully </br>';
if ( isset( $_POST['submit'] ) ) {
  $name =$_REQUEST['cl_name'];
  $phone = $_REQUEST['phonee'];
$e_maile = $_REQUEST['mail'];

$location = $_REQUEST['loc'];
$material = $_REQUEST['materiall'];
$quantity = $_REQUEST['quant'];
$price = $_REQUEST['pricee'];

$sql="insert into company values('$material','$quantity','$price','$name','$phone','$e_maile','$location')";
//$sql3="insert into userr values('$phone')";
if(mysqli_query($conn, $sql)){

  echo "Well Done Matirial Is Recorded";
}


else{
echo "Could not insert record: ". mysqli_error($conn);
}
}
}
//insert in section table

mysqli_close($conn);
?>
<form action="orders.php" method="post">
<button type="submit"  style="width: 200px; height: 60px; " name="home">Back TO Home OF Orders </button>

</form>

</center>

</body>
</html>
