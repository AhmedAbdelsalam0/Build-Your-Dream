<html>
<head>
  <meta chaset="utf-8">
  <meta name="description"contain="users of bulding company">
  <title>bulding company</title>
</head>
<style>
h1{
  align:center;
  font-size: 60px;
  color:#b15ec4;

  font-style: italic;


}
button{
  background-color:#EEE;
  border: 2px solid #FF00FF;
  color:#000000;
  padding:1em 1.5em;
  text-align: center;
  text-decoration:none;
  font-size: 1em;
  display:inline;
  font-style:normal;
  width:50;
  border-radius:5px;
  box-shadow: 4px 4px 9px 0 #ADD8E6 ;
  font:bold;

}
header{
  background:#DDD;
  color:#676767;
  font-size: 50px;
  text-align: center;
  font-style: italic;



}
p{
  font-size: 20px;
  color:#000;
  font-style:italic;
}
h2{
  align:center;
  font-size: 30px;
  color:#676767;

  font-style: italic;


}

</style>
<body  style="background-image: url(https://holidaypropertysolutions.com/realestate/frontend/assets/img/propertymanagement.jpg); background-repeat: no-repeat;
background-attachment: fixed;background-size:cover;
 ">
  <center>
    <header>Information About Our Company</header>
    <h1> Welcome With YOU </h1>
  </center>

    <p> ->>The home of  This Web Contain A video about Building, and menu of an operation in it .</p>
    <p>->>If you want to access on user click users .</p>
    <p> ->>If you want to access on buildings click buildings.</p>
    <p>->>If you want to access on orders and materials click orders.</p>
    <p>->>>If you  want to know more about our web click about us.</p>
    <p>->>>If you  need a help click help.</p>
    <p>->>If you want to inquire about any thing or want to contact with us click contact us.</p>
    <center>
      <h2> THANKS FOR CONTRATING WITH US </h2>
    </form>

    <hr><hr>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <form action="building_company.php" method="post">

                                     <button type="submit"  style="width: 200px; height: 50px; " name="button">Back to Home </button>
                                       </form>
    </center>
  </body>
  </html>
